"""Synthetic examples only."""
